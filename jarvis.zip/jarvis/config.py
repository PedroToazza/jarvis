"""
╔══════════════════════════════════════════╗
║          JARVIS — config.py              ║
╚══════════════════════════════════════════╝
"""
import sys
import os

def resource_path(relative):
    if hasattr(sys, '_MEIPASS'):
        return os.path.join(sys._MEIPASS, relative)
    return os.path.join(os.path.dirname(os.path.abspath(__file__)), relative)

# ─── VOZ ──────────────────────────────────────────────────────────────
WAKE_WORD       = "jarvis"
COMMAND_TIMEOUT = 8

# ─── PALMAS ───────────────────────────────────────────────────────────
CLAP_PEAK_THRESHOLD    = 0.06
CLAP_SUSTAIN_THRESHOLD = 0.012
CLAP_MAX_INTERVAL      = 0.9
CLAP_COOLDOWN          = 2.5

# ─── SPOTIFY ──────────────────────────────────────────────────────────
SPOTIFY_CLIENT_ID     = "8fa9b47fdb9a40449e15db0652dab05a"
SPOTIFY_CLIENT_SECRET = "e2bed9b2e098460ca1cd762eeeece671"
SPOTIFY_REDIRECT_URI  = "http://127.0.0.1:8888/callback"
SPOTIFY_SCOPE         = (
    "user-modify-playback-state "
    "user-read-playback-state "
    "playlist-read-private "
    "playlist-read-collaborative"
)

# ─── TTS Microsoft Edge ──────────────────────────────────────────────
# Vozes pt-BR:
#   pt-BR-AntonioNeural              ← padrão
#   pt-BR-MacerioMultilingualNeural  ← mais natural
#   pt-BR-FranciscaNeural            ← feminina
#   pt-BR-ThalitaMultilingualNeural  ← feminina mais jovem
TTS_VOICE  = "pt-BR-AntonioNeural"
TTS_RATE   = 165
TTS_VOLUME = 0.9

# ─── IA (Gemini 1.5 Flash) ───────────────────────────────────────────
# Grátis 1500 req/dia: https://aistudio.google.com/apikey
GEMINI_API_KEY = "AIzaSyBvt1WiDnSASNIKnrz3g5wwL31xbiEz8bQ"